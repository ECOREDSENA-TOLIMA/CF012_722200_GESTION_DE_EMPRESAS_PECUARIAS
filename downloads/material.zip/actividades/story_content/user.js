function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5YXQbPEomRT":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

