function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6o8uLACb4FN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

